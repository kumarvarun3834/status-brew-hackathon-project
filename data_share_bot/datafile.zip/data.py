# here the internal data ie private data of bot is bei
baseurl="https://api.telegram.org/"
TOKEN="bot7452688807:AAFewUJKZOniA8ldH9EACAh784l8KYSJE6g/"
store="-4566364009"
monitor="-1002186023307"
cloud="-1002344593355"
public="unicloudgndu"
mid="-1002474677568"

# mid area {'update_id': 771734112, 'message': {'message_id': 5292, 'from': {'id': 1789016259, 'is_bot': False, 'first_name': 'BEELZEBUB', 'language_code': 'en'}, 'chat': {'id': -4501586617, 'title': 'unimid', 'type': 'group', 'all_members_are_administrators': True}, 'date': 1725710306, 'new_chat_title': 'unimid'}}

# public  {'update_id': 771734111, 'channel_post': {'message_id': 3, 'sender_chat': {'id': -1002344593355, 'title': 'unicloud', 'username': 'unicloudgndu', 'type': 'channel'}, 'chat': {'id': -1002344593355, 'title': 'unicloud', 'username': 'unicloudgndu', 'type': 'channel'}, 'date': 1725706499, 'text': 'hlo'}}   
# {'update_id': 771734108, 'channel_post': {'message_id': 2, 'sender_chat': {'id': -1002344593355, 'title': 'unicloud', 'username': 'unicloudgndu', 'type': 'channel'}, 'chat': {'id': -1002344593355, 'title': 'unicloud', 'username': 'unicloudgndu', 'type': 'channel'}, 'date': 1725705825, 'text': 'hi'}} 

# {'update_id': 771734109, 'message': {'message_id': 5290, 'from': {'id': 1789016259, 'is_bot': False, 'first_name': 'BEELZEBUB', 'language_code': 'en'}, 'chat': {'id': -4501586617, 'title': 'unicloud', 'type': 'group', 'all_members_are_administrators': True}, 'date': 1725705946, 'text': 'hell'}}

# {'update_id': 771733109, 'message': {'message_id': 200, 'from': {'id': 1789016259, 'is_bot': False, 'first_name': 'BEELZEBUB', 'language_code': 'en'}, 'chat': {'id': -4530864155, 'title': 'Monitor for uni', 'type': 'group', 'all_members_are_administrators': True}, 'date': 1723957251, 'new_chat_participant': {'id': 7452688807, 'is_bot': True, 'first_name': 'test case', 'username': 'testcasewhile1bot'}, 'new_chat_member': {'id': 7452688807, 'is_bot': True, 'first_name': 'test case', 'username': 'testcasewhile1bot'}, 'new_chat_members': [{'id': 7452688807, 'is_bot': True, 'first_name': 'test case', 'username': 'testcasewhile1bot'}]}}
# {'update_id': 771733110, 'message': {'message_id': 201, 'from': {'id': 1789016259, 'is_bot': False, 'first_name': 'BEELZEBUB', 'language_code': 'en'}, 'chat': {'id': -4530864155, 'title': 'Monitor for uni', 'type': 'group', 'all_members_are_administrators': True}, 'date': 1723957316, 'text': 'Hi'}}